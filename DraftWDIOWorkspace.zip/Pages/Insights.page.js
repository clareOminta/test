import { GeneralFunctions } from "../utils/generalFunctions"
import testData  from '../testData/testData.json'

export class Insights {

    get homePage() { return $("//img[2][@alt='Securian Financial Home']")}

    get currentAge() { return $("#current-age")}

    get retireAge() { return $("#retirement-age")}

    get currentIncome() { return "#current-income"}

    get spouseIncome() { return "#spouse-income"}

    get retirementSavingsBalance() { return "#current-total-savings" }

    get currentAnnualSavings() { return "#current-annual-savings"}

    get savingsIncreaseRate() { return "#savings-increase-rate"}

    get calculateResultsSubmit() { return $("//button[contains(text(),'Calculate')]")}

    get resultsText() { return $("#calculator-results-container>h3")}

    get displayAdditionalSecurityFields() { return $("//label[@for='yes-social-benefits']")} 

    get hideAdditionalSecurityFields() { return $("#no-social-benefits")}

    get socialSecurityOverride() { return $("#social-security-override")}

    get adjustDefaultValues() { return $("//a[contains(text(),'Adjust default values')]")}

    get retirementDuration() { return $("#retirement-duration")}

    get retirementAnnualIncome() { return $("#retirement-annual-income")}

    get preRetirementROI() { return $("#pre-retirement-roi")}

    get postRetirementROI() { return $("#post-retirement-roi")}

    get saveChanges() { return $("//button[contains(text(),'Save changes')]")}


    async launchApp() {
        await browser.url(testData.url)
        await browser.waitUntil(
            async () => await browser.execute(()=>  document.readyState ==='complete'),
            {timeout : 10000}
        )

    }
    async submitRequiredFields() {
        await GeneralFunctions.setInputValue(await this.currentAge, testData.Fields.currentAge)
        await GeneralFunctions.setInputValue(await this.retireAge, testData.Fields.retirementAge)
        await GeneralFunctions.executeScript(this.currentIncome, testData.Fields.currenIncome)
        await GeneralFunctions.executeScript(this.retirementSavingsBalance, testData.Fields.currenRetirementSavings)
        await GeneralFunctions.executeScript(this.currentAnnualSavings, testData.Fields.currenRetirementContribution)
        await GeneralFunctions.executeScript(this.savingsIncreaseRate, testData.Fields.annualRetirementContribution)
        await GeneralFunctions.click(await this.calculateResultsSubmit)
        await this.resultsText.waitForDisplayed({timeout: 10000})
        return await this.resultsText.getText()
    }

    async validateAdditionalSecurityField(additionalSecurity) {
        if(additionalSecurity === 'Yes'){
            await GeneralFunctions.click(await this.displayAdditionalSecurityFields)
            await this.socialSecurityOverride.waitForDisplayed({timeout:10000})
            return await this.socialSecurityOverride.isDisplayed()? true : false
        }else{
            return await this.socialSecurityOverride.isDisplayed()? true : false
        }

    }

    async submitFormWithAllFields() {
        await GeneralFunctions.executeScript(this.spouseIncome, testData.Fields.spouseAnnualIncome)
        return await this.submitRequiredFields()
    }

    async validateAdjustDefaultValues() {
        await GeneralFunctions.click(await this.adjustDefaultValues)
        await GeneralFunctions.setInputValue(await this.retirementDuration, testData.Fields.retirementYears)
        await GeneralFunctions.setInputValue(await this.retirementAnnualIncome, testData.Fields.percentOfFinalIncomeDesired)
        await GeneralFunctions.setInputValue(await this.preRetirementROI, testData.Fields.preRetirementInvestmentReturn)
        await GeneralFunctions.setInputValue(await this.postRetirementROI, testData.Fields.postRetirementInvestmentReturn)
        await GeneralFunctions.click(await this.saveChanges)
    }

}